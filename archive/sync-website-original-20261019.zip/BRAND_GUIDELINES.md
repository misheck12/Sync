# SYNC BRAND GUIDELINES

## Brand Identity

**Tagline:** "Run your school in sync"

**Mission:** Empowering African schools with AI-powered management tools

**Brand Personality:**
- Professional yet approachable
- Innovative and forward-thinking
- Reliable and trustworthy
- Education-focused
- African-centric

---

## Logo

### Primary Logo
The Sync logo consists of:
- A circular design with blue and orange swoosh representing synchronization
- A graduation cap and book icon in the center symbolizing education
- The wordmark "SYNC" in bold navy blue
- The tagline "Run your school in sync" below

### Logo Usage
- Minimum size: 120px width for digital, 1 inch for print
- Clear space: Maintain space equal to the height of the "S" around the logo
- Do not stretch, rotate, or distort the logo
- Do not change the colors
- Do not add effects (shadows, gradients, etc.)

### Logo Variations
- Full color (primary)
- White version (for dark backgrounds)
- Navy blue monochrome (when color is limited)

---

## Color Palette

### Primary Colors

**Primary Blue**
- Hex: `#0047AB`
- RGB: 0, 71, 171
- CMYK: 100, 58, 0, 33
- Usage: Primary brand color, buttons, headers, key UI elements

**Primary Dark Blue**
- Hex: `#003366`
- RGB: 0, 51, 102
- CMYK: 100, 50, 0, 60
- Usage: Text, dark backgrounds, hover states

### Secondary Colors

**Accent Orange**
- Hex: `#FF9933`
- RGB: 255, 153, 51
- CMYK: 0, 40, 80, 0
- Usage: Call-to-action, highlights, accents, energy

**Accent Light Orange**
- Hex: `#FFB366`
- RGB: 255, 179, 102
- CMYK: 0, 30, 60, 0
- Usage: Subtle accents, backgrounds, hover states

### Neutral Colors

**Text Primary**
- Hex: `#0f172a`
- Usage: Body text, headings

**Text Secondary**
- Hex: `#64748b`
- Usage: Secondary text, captions, labels

**Background**
- Hex: `#ffffff`
- Usage: Main background

**Surface**
- Hex: `#f8fafc`
- Usage: Card backgrounds, sections

**Border**
- Hex: `#e2e8f0`
- Usage: Dividers, borders, outlines

### Accent Colors

**Success Green**
- Hex: `#10b981`
- Usage: Success messages, positive indicators

**Warning Yellow**
- Hex: `#f59e0b`
- Usage: Warnings, alerts

**Error Red**
- Hex: `#ef4444`
- Usage: Errors, critical alerts

---

## Typography

### Primary Font: Inter
- **Headings:** Inter Bold (700-800)
- **Body:** Inter Regular (400)
- **Emphasis:** Inter Medium (500-600)
- **Fallback:** -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif

### Font Sizes
- **Hero Title:** 56px (desktop), 36px (mobile)
- **Section Title:** 48px (desktop), 32px (mobile)
- **Heading 1:** 36px
- **Heading 2:** 28px
- **Heading 3:** 24px
- **Body Large:** 20px
- **Body:** 16px
- **Small:** 14px
- **Caption:** 12px

### Line Height
- Headings: 1.1-1.2
- Body text: 1.6
- Captions: 1.4

---

## Gradients

### Primary Gradient
- Direction: 135deg (diagonal)
- Start: Primary Blue (#0047AB)
- End: Accent Orange (#FF9933)
- Usage: Hero sections, CTAs, special highlights

### Subtle Gradient
- Direction: 135deg
- Start: Surface (#f8fafc)
- End: Light Blue (#e0e7ff)
- Usage: Background sections, subtle emphasis

---

## Iconography

### Style
- Line icons (2px stroke)
- Rounded corners (4px radius)
- Consistent sizing (24px standard, 32px large, 16px small)
- Use emoji for quick recognition (👨‍🎓 💰 📚 🤖 etc.)

### Color
- Primary icons: Primary Blue (#0047AB)
- Secondary icons: Text Secondary (#64748b)
- Accent icons: Accent Orange (#FF9933)

---

## Photography & Imagery

### Style
- Authentic African school environments
- Diverse students and teachers
- Natural lighting, warm tones
- Focus on technology integration
- Show real classroom moments

### Treatment
- Slight warm color grade
- High contrast
- Sharp focus
- Avoid overly staged photos

---

## Voice & Tone

### Brand Voice
- **Professional:** We're experts in education technology
- **Approachable:** We speak like educators, not engineers
- **Empowering:** We help schools succeed
- **Local:** We understand African education

### Tone Guidelines
- Use "we" and "you" (conversational)
- Avoid jargon and technical terms
- Be specific with numbers and results
- Show, don't just tell
- Celebrate success stories

### Example Phrases
✅ "Save 12+ hours per week on admin tasks"
✅ "47 schools trust Sync to run their operations"
✅ "Increase fee collection by 30% with mobile money"
❌ "Leverage our SaaS platform for operational efficiency"
❌ "Utilize cutting-edge technology solutions"

---

## UI Components

### Buttons

**Primary Button**
- Background: Primary Blue (#0047AB)
- Text: White
- Padding: 12px 24px
- Border radius: 8px
- Hover: Primary Dark Blue (#003366)

**Secondary Button**
- Background: Transparent
- Border: 2px solid Primary Blue
- Text: Primary Blue
- Hover: Filled with Primary Blue

**CTA Button**
- Background: Accent Orange (#FF9933)
- Text: White
- Larger padding: 16px 32px
- Hover: Darker orange

### Cards
- Background: White
- Border: 1px solid Border (#e2e8f0)
- Border radius: 16px
- Shadow: Subtle (0 1px 3px rgba(0,0,0,0.1))
- Hover: Lift effect (translateY(-4px))

### Forms
- Input border: 1px solid Border
- Focus: Primary Blue border
- Border radius: 8px
- Padding: 12px 16px

---

## Spacing System

Use 8px base unit:
- 4px (0.25rem) - Tiny
- 8px (0.5rem) - Extra small
- 12px (0.75rem) - Small
- 16px (1rem) - Base
- 24px (1.5rem) - Medium
- 32px (2rem) - Large
- 48px (3rem) - Extra large
- 64px (4rem) - XXL
- 80px (5rem) - XXXL
- 120px (7.5rem) - Section padding

---

## Animation & Motion

### Timing
- Fast: 150ms (hover, small changes)
- Normal: 300ms (transitions, reveals)
- Slow: 500ms (page transitions, complex animations)

### Easing
- Standard: ease-out
- Entrance: ease-out
- Exit: ease-in

### Effects
- Hover: translateY(-2px) + shadow increase
- Click: Scale(0.98)
- Fade in: opacity 0 → 1
- Slide in: translateY(20px) → 0

---

## Accessibility

### Contrast Ratios
- Body text: Minimum 4.5:1
- Large text: Minimum 3:1
- UI components: Minimum 3:1

### Focus States
- Visible focus indicator (2px outline)
- Color: Primary Blue
- Offset: 2px

### Alt Text
- All images must have descriptive alt text
- Decorative images: alt=""

---

## Brand Applications

### Website
- Use full color logo in header
- Primary Blue for navigation and CTAs
- Accent Orange for highlights and important actions
- White space is important - don't overcrowd

### Marketing Materials
- Lead with the logo
- Use gradient for impact
- Include real school photos
- Show tangible results (numbers, testimonials)

### Social Media
- Profile picture: Circular logo (icon only)
- Cover images: Use gradient background
- Posts: Mix of product screenshots and school photos
- Hashtags: #SyncSchools #EdTechAfrica #ZambianEducation

### Presentations
- Title slide: Logo + gradient background
- Content slides: White background, blue headers
- Use icons and visuals liberally
- Keep text minimal

---

## Don'ts

❌ Don't use the old blue (#2563eb) - use brand blue (#0047AB)
❌ Don't use purple gradients - use blue to orange
❌ Don't stretch or distort the logo
❌ Don't use the logo on busy backgrounds
❌ Don't use fonts other than Inter
❌ Don't use stock photos of non-African schools
❌ Don't use technical jargon in marketing
❌ Don't forget the tagline: "Run your school in sync"

---

## Contact

For brand assets, questions, or approvals:
- Email: brand@sync.education
- Brand assets: [Link to brand asset folder]

**Last Updated:** March 2026
**Version:** 1.0
