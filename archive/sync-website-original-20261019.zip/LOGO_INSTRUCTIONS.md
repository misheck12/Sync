# Logo Setup Instructions

## Required File

You need to add your logo file to this directory:

**Filename:** `logo.png`  
**Location:** `sync-website/logo.png`

## Logo Specifications

### Dimensions
- **Width:** 360px
- **Height:** 100px
- **Aspect Ratio:** 3.6:1
- **Resolution:** 2x for retina displays (720x200px actual, scaled to 360x100px)

### Format
- **File Type:** PNG
- **Background:** Transparent
- **Color Mode:** RGB
- **Bit Depth:** 24-bit with alpha channel

### Content
Your logo should include:
1. The circular icon (blue and orange swoosh with graduation cap)
2. "SYNC" wordmark in navy blue
3. "Run your school in sync" tagline

### Colors (Must Match Brand)
- **Primary Blue:** #0047AB (RGB: 0, 71, 171)
- **Navy Blue:** #003366 (RGB: 0, 51, 102)
- **Accent Orange:** #FF9933 (RGB: 255, 153, 51)
- **Light Orange:** #FFB366 (RGB: 255, 179, 102)

## Where the Logo is Used

The logo appears in two places on the website:

1. **Navigation Bar** (Top of page)
   - Size: 180x50px
   - Background: White
   - Full color version

2. **Footer** (Bottom of page)
   - Size: 150x42px
   - Background: Dark navy (#0f172a)
   - White inverted version (applied via CSS filter)

## Export Settings

### From Adobe Illustrator:
1. File → Export → Export for Screens
2. Format: PNG
3. Scale: 2x
4. Artboard size: 360x100px
5. Background: Transparent
6. Save as: `logo.png`

### From Figma:
1. Select logo frame
2. Export settings:
   - Format: PNG
   - Scale: 2x
   - Include "Export" suffix: No
3. Export as: `logo.png`

### From Photoshop:
1. File → Export → Export As
2. Format: PNG
3. Transparency: Checked
4. Canvas size: 720x200px (will display at 360x100px)
5. Save as: `logo.png`

## Testing

After adding the logo:

1. Open `index.html` in a browser
2. Check the navigation bar - logo should appear clearly
3. Scroll to footer - logo should appear in white
4. Test on mobile - logo should scale appropriately
5. Check on retina displays - logo should be crisp

## Fallback

If you don't have the logo file yet, the website will show:
- A broken image icon in the navigation
- A broken image icon in the footer

The website will still function, but won't look professional without the logo.

## Alternative: SVG Format

For even better quality, you can use SVG format:

**Filename:** `logo.svg`

Then update `index.html`:
```html
<!-- Change from: -->
<img src="logo.png" alt="Sync Logo" width="180" height="50">

<!-- To: -->
<img src="logo.svg" alt="Sync Logo" width="180" height="50">
```

SVG advantages:
- Scales perfectly at any size
- Smaller file size
- Better for retina displays
- Can be styled with CSS

## Need Help?

If you need help creating or exporting the logo:
1. Contact your designer
2. Use the brand guidelines in `BRAND_GUIDELINES.md`
3. Ensure colors match exactly: #0047AB (blue) and #FF9933 (orange)

## Quick Checklist

- [ ] Logo file created
- [ ] Saved as `logo.png` (or `logo.svg`)
- [ ] Placed in `sync-website/` directory
- [ ] Dimensions: 360x100px (or 720x200px @2x)
- [ ] Transparent background
- [ ] Colors match brand (#0047AB, #FF9933)
- [ ] Tested in browser
- [ ] Looks good on mobile
- [ ] Looks crisp on retina displays

---

**Once you add the logo, the website will be complete and ready to deploy!**
