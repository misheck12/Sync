# Sync School Management System - Landing Page

A modern, responsive landing page for Sync - an AI-powered school management system built for Zambian schools.

## 🎨 Brand Assets Required

**IMPORTANT:** Before deploying, add the Sync logo to the website:

1. Save your logo image as `logo.png` in the `sync-website/` directory
2. Recommended dimensions: 360x100px (transparent background)
3. Format: PNG with transparency
4. The logo should include:
   - The circular blue/orange icon
   - "SYNC" wordmark
   - "Run your school in sync" tagline

**Logo Specifications:**
- Primary colors: Blue (#0047AB) and Orange (#FF9933)
- Transparent background
- High resolution (2x for retina displays recommended)

**Brand Colors:**
- Primary Blue: `#0047AB`
- Primary Dark: `#003366`
- Accent Orange: `#FF9933`
- Accent Light: `#FFB366`

See `BRAND_GUIDELINES.md` for complete brand specifications.

## 🚀 Features

- **Responsive Design** - Works perfectly on desktop, tablet, and mobile
- **Modern UI** - Clean, professional design with smooth animations
- **Fast Loading** - Optimized for performance
- **SEO Optimized** - Meta tags and semantic HTML
- **Accessible** - WCAG compliant
- **Interactive** - Smooth scrolling, hover effects, and animations

## 📁 File Structure

```
sync-website/
├── index.html          # Main HTML file
├── styles.css          # All CSS styles
├── script.js           # JavaScript functionality
└── README.md           # This file
```

## 🎨 Sections

1. **Navigation** - Sticky header with logo and menu
2. **Hero Section** - Eye-catching headline with CTA buttons
3. **Trust Section** - Social proof with school logos
4. **Features** - 10 feature cards showcasing all modules
5. **Benefits** - Key metrics and results
6. **Testimonials** - Customer reviews
7. **Pricing** - Three pricing tiers
8. **CTA Section** - Final call-to-action
9. **Footer** - Links and contact information

## 🛠️ Customization

### Colors

Edit the CSS variables in `styles.css`:

```css
:root {
    --primary: #2563eb;        /* Primary brand color */
    --primary-dark: #1e40af;   /* Darker shade */
    --secondary: #475569;      /* Secondary color */
    --accent: #f59e0b;         /* Accent color */
    --success: #10b981;        /* Success color */
}
```

### Content

Edit the HTML in `index.html`:

- **Hero Title**: Line 42
- **Features**: Lines 120-280
- **Testimonials**: Lines 340-380
- **Pricing**: Lines 420-520
- **Contact Info**: Lines 620-640

### Images

To add images:

1. Create an `images/` folder
2. Add your images
3. Update `<img>` tags in HTML
4. Use lazy loading: `<img class="lazy" data-src="images/your-image.jpg" alt="Description">`

## 📱 Responsive Breakpoints

- **Desktop**: 1200px and above
- **Tablet**: 768px - 1199px
- **Mobile**: Below 768px

## 🚀 Deployment

### Option 1: Static Hosting (Recommended)

Deploy to any static hosting service:

- **Netlify**: Drag and drop the folder
- **Vercel**: Connect to Git repository
- **GitHub Pages**: Push to GitHub and enable Pages
- **AWS S3**: Upload files to S3 bucket

### Option 2: Traditional Web Server

Upload files to your web server via FTP/SFTP:

```bash
# Example using SCP
scp -r sync-website/* user@yourserver.com:/var/www/html/
```

### Option 3: Docker

Create a `Dockerfile`:

```dockerfile
FROM nginx:alpine
COPY . /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

Build and run:

```bash
docker build -t sync-website .
docker run -p 80:80 sync-website
```

## 🔧 Development

### Local Development

Simply open `index.html` in your browser, or use a local server:

```bash
# Python
python -m http.server 8000

# Node.js (http-server)
npx http-server

# PHP
php -S localhost:8000
```

Then visit `http://localhost:8000`

### Live Reload (Optional)

Install live-server for auto-reload during development:

```bash
npm install -g live-server
live-server
```

## 📊 Performance Optimization

### Already Implemented:
- ✅ Minified CSS (can be further compressed)
- ✅ Optimized animations
- ✅ Lazy loading for images
- ✅ Efficient JavaScript
- ✅ No external dependencies (except Google Fonts)

### Further Optimizations:
1. **Minify CSS/JS** - Use tools like `cssnano` and `terser`
2. **Compress Images** - Use WebP format
3. **Add CDN** - Serve static assets from CDN
4. **Enable Caching** - Set cache headers on server
5. **Add Service Worker** - For offline support

## 🔗 Integration

### Connect to Backend

Update the form submission URLs in `script.js`:

```javascript
// Line 150-160
document.querySelectorAll('a[href="#trial"]').forEach(button => {
    button.addEventListener('click', (e) => {
        e.preventDefault();
        window.location.href = 'https://app.sync.education/signup?trial=true';
    });
});
```

### Add Analytics

Add Google Analytics to `index.html` before `</head>`:

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

### Add Live Chat

Add Intercom, Drift, or Tawk.to widget before `</body>`:

```html
<!-- Tawk.to Live Chat -->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/YOUR_PROPERTY_ID/YOUR_WIDGET_ID';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
```

## 🎯 SEO Checklist

- [x] Meta description
- [x] Meta keywords
- [x] Semantic HTML (h1, h2, etc.)
- [x] Alt text for images (when added)
- [ ] Open Graph tags (for social sharing)
- [ ] Twitter Card tags
- [ ] Sitemap.xml
- [ ] Robots.txt
- [ ] Schema.org markup

### Add Open Graph Tags

Add to `<head>` in `index.html`:

```html
<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="https://sync.education/">
<meta property="og:title" content="Sync - AI-Powered School Management System">
<meta property="og:description" content="Manage students, fees, academics, and communication in one platform.">
<meta property="og:image" content="https://sync.education/images/og-image.jpg">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="https://sync.education/">
<meta property="twitter:title" content="Sync - AI-Powered School Management System">
<meta property="twitter:description" content="Manage students, fees, academics, and communication in one platform.">
<meta property="twitter:image" content="https://sync.education/images/twitter-image.jpg">
```

## 📧 Contact Forms

To make the contact forms functional, you can use:

1. **Formspree** - https://formspree.io/
2. **Netlify Forms** - Built-in with Netlify
3. **EmailJS** - https://www.emailjs.com/
4. **Custom Backend** - Connect to your API

Example with Formspree:

```html
<form action="https://formspree.io/f/YOUR_FORM_ID" method="POST">
  <input type="email" name="email" required>
  <textarea name="message" required></textarea>
  <button type="submit">Send</button>
</form>
```

## 🔒 Security Headers

Add these headers to your server configuration:

```
X-Frame-Options: DENY
X-Content-Type-Options: nosniff
X-XSS-Protection: 1; mode=block
Referrer-Policy: strict-origin-when-cross-origin
Content-Security-Policy: default-src 'self'
```

## 📱 Progressive Web App (Optional)

To make this a PWA, add:

1. **manifest.json**
2. **Service Worker**
3. **Icons** (192x192, 512x512)

## 🐛 Browser Support

- ✅ Chrome (latest)
- ✅ Firefox (latest)
- ✅ Safari (latest)
- ✅ Edge (latest)
- ✅ Mobile browsers

## 📝 License

Copyright © 2026 Sync. All rights reserved.

## 🤝 Support

For questions or support:
- Email: info@sync.education
- Phone: +260 XXX XXX XXX
- Website: https://sync.education

## 🚀 Next Steps

1. **Add Real Content**: Replace placeholder text with actual content
2. **Add Images**: Add screenshots, logos, and photos
3. **Connect Forms**: Link forms to backend or form service
4. **Add Analytics**: Install Google Analytics or similar
5. **Test**: Test on all devices and browsers
6. **Deploy**: Deploy to production hosting
7. **Monitor**: Set up uptime monitoring

---

**Built with ❤️ for Zambian Schools**

