# Sync Brand Colors - Quick Reference

## Primary Colors

### Primary Blue
```
Hex:  #0047AB
RGB:  0, 71, 171
CMYK: 100, 58, 0, 33
```
**Usage:** Main brand color, primary buttons, headers, links, key UI elements

### Primary Dark Blue
```
Hex:  #003366
RGB:  0, 51, 102
CMYK: 100, 50, 0, 60
```
**Usage:** Text, dark backgrounds, hover states, footer

---

## Accent Colors

### Accent Orange
```
Hex:  #FF9933
RGB:  255, 153, 51
CMYK: 0, 40, 80, 0
```
**Usage:** Call-to-action buttons, highlights, important elements, energy

### Accent Light Orange
```
Hex:  #FFB366
RGB:  255, 179, 102
CMYK: 0, 30, 60, 0
```
**Usage:** Subtle accents, hover states, backgrounds

---

## Gradients

### Primary Gradient (Blue to Orange)
```css
background: linear-gradient(135deg, #0047AB 0%, #FF9933 100%);
```
**Usage:** Hero sections, CTAs, special highlights, brand moments

### Subtle Background Gradient
```css
background: linear-gradient(135deg, #f8fafc 0%, #e3f2fd 100%);
```
**Usage:** Hero background, section backgrounds

---

## Neutral Colors

### Text Primary
```
Hex: #0f172a
```
**Usage:** Body text, headings, primary content

### Text Secondary
```
Hex: #64748b
```
**Usage:** Secondary text, captions, labels, descriptions

### Background
```
Hex: #ffffff
```
**Usage:** Main page background, card backgrounds

### Surface
```
Hex: #f8fafc
```
**Usage:** Alternate backgrounds, card surfaces, sections

### Border
```
Hex: #e2e8f0
```
**Usage:** Dividers, borders, outlines, separators

---

## Semantic Colors

### Success Green
```
Hex: #10b981
```
**Usage:** Success messages, positive indicators, checkmarks

### Warning Yellow
```
Hex: #f59e0b
```
**Usage:** Warnings, alerts, caution messages

### Error Red
```
Hex: #ef4444
```
**Usage:** Errors, critical alerts, destructive actions

---

## Color Combinations

### High Contrast (Accessibility)
✅ Primary Blue (#0047AB) on White (#ffffff) - WCAG AAA
✅ Primary Dark (#003366) on White (#ffffff) - WCAG AAA
✅ White (#ffffff) on Primary Blue (#0047AB) - WCAG AAA
✅ White (#ffffff) on Accent Orange (#FF9933) - WCAG AA

### Recommended Pairings
- **Hero Section:** Primary Blue + Accent Orange gradient
- **Buttons:** Primary Blue background + White text
- **CTAs:** Accent Orange background + White text
- **Cards:** White background + Primary Blue accents
- **Text:** Text Primary (#0f172a) on White background

---

## CSS Variables (Already in styles.css)

```css
:root {
    --primary: #0047AB;
    --primary-dark: #003366;
    --secondary: #475569;
    --accent: #FF9933;
    --accent-light: #FFB366;
    --success: #10b981;
    --background: #ffffff;
    --surface: #f8fafc;
    --text-primary: #0f172a;
    --text-secondary: #64748b;
    --border: #e2e8f0;
}
```

**Usage in CSS:**
```css
.button {
    background: var(--primary);
    color: var(--background);
}

.button:hover {
    background: var(--primary-dark);
}

.cta-button {
    background: var(--accent);
}
```

---

## Color Psychology

### Blue (#0047AB)
- Trust and reliability
- Professionalism
- Intelligence and wisdom
- Stability and confidence
- Perfect for education and technology

### Orange (#FF9933)
- Energy and enthusiasm
- Creativity and innovation
- Warmth and friendliness
- Action and motivation
- Balances the seriousness of blue

### Combined (Blue + Orange)
- Professional yet approachable
- Trustworthy yet innovative
- Stable yet dynamic
- Perfect balance for education technology

---

## Don'ts

❌ Don't use the old blue (#2563eb) - always use #0047AB
❌ Don't use purple gradients - use blue to orange
❌ Don't use colors outside this palette
❌ Don't reduce contrast below WCAG AA standards
❌ Don't use orange for error messages (use red #ef4444)
❌ Don't use blue for success messages (use green #10b981)

---

## Color Accessibility

All color combinations meet WCAG 2.1 standards:

| Foreground | Background | Contrast | Rating |
|------------|------------|----------|--------|
| #0047AB | #ffffff | 8.59:1 | AAA ✅ |
| #003366 | #ffffff | 12.63:1 | AAA ✅ |
| #ffffff | #0047AB | 8.59:1 | AAA ✅ |
| #ffffff | #FF9933 | 3.95:1 | AA ✅ |
| #0f172a | #ffffff | 16.89:1 | AAA ✅ |
| #64748b | #ffffff | 4.73:1 | AA ✅ |

---

## Quick Copy-Paste

**Primary Blue:** `#0047AB`  
**Primary Dark:** `#003366`  
**Accent Orange:** `#FF9933`  
**Accent Light:** `#FFB366`  
**Text Primary:** `#0f172a`  
**Text Secondary:** `#64748b`  
**Background:** `#ffffff`  
**Surface:** `#f8fafc`  
**Border:** `#e2e8f0`  
**Success:** `#10b981`  
**Warning:** `#f59e0b`  
**Error:** `#ef4444`

---

**Last Updated:** March 2026  
**Version:** 1.0
